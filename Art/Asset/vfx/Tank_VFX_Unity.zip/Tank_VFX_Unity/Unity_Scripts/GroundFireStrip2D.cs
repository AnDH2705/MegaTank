using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[DisallowMultipleComponent]
[RequireComponent(typeof(SortingGroup))]
public sealed class GroundFireStrip2D : MonoBehaviour
{
    public Sprite[] frames;
    [Min(0f)] public float width = 4f;
    [Min(0.01f)] public float cellHeight = 1.5f;
    [Range(0.4f, 0.9f)] public float spacingRatio = 0.72f;
    [Min(1f)] public float framesPerSecond = 16f;

    private readonly List<SpriteRenderer> tiles = new List<SpriteRenderer>();
    private SpriteMask cropMask;
    private Sprite maskSprite;
    private Texture2D maskTexture;
    private float elapsed;
    private float lastWidth = -1f;
    private float lastHeight = -1f;
    private float lastSpacing = -1f;
    private Sprite lastFirstFrame;

    private void Start() { Rebuild(); }

    public void SetWidth(float value)
    {
        width = Mathf.Max(0f, value);
        if (isActiveAndEnabled) Rebuild();
    }

    private void EnsureMask()
    {
        if (cropMask != null) return;
        maskTexture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
        maskTexture.SetPixels(new Color[] { Color.white, Color.white, Color.white, Color.white });
        maskTexture.Apply();
        maskSprite = Sprite.Create(maskTexture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f), 2f);
        GameObject maskObject = new GameObject("Fire width mask");
        maskObject.transform.SetParent(transform, false);
        cropMask = maskObject.AddComponent<SpriteMask>();
        cropMask.sprite = maskSprite;
    }

    private void Rebuild()
    {
        if (frames == null || frames.Length == 0 || frames[0] == null)
        {
            foreach (SpriteRenderer tile in tiles) tile.enabled = false;
            lastFirstFrame = null;
            return;
        }
        EnsureMask();
        width = Mathf.Max(0f, width);
        cellHeight = Mathf.Max(0.01f, cellHeight);
        spacingRatio = Mathf.Clamp(spacingRatio, 0.4f, 0.9f);
        float nativeHeight = frames[0].rect.height / frames[0].pixelsPerUnit;
        float scale = cellHeight / nativeHeight;
        float tileWidth = frames[0].rect.width / frames[0].pixelsPerUnit * scale;
        float step = Mathf.Max(0.001f, tileWidth * spacingRatio);
        int count = width > 0f ? Mathf.CeilToInt(width / step) + 2 : 0;
        while (tiles.Count < count)
        {
            GameObject tileObject = new GameObject("Flame " + tiles.Count);
            tileObject.transform.SetParent(transform, false);
            SpriteRenderer tile = tileObject.AddComponent<SpriteRenderer>();
            tile.maskInteraction = SpriteMaskInteraction.VisibleInsideMask;
            tiles.Add(tile);
        }
        for (int i = 0; i < tiles.Count; i++)
        {
            tiles[i].enabled = i < count;
            if (i >= count) continue;
            tiles[i].transform.localPosition = new Vector3(-width * 0.5f - step * 0.5f + i * step, 0f, 0f);
            tiles[i].transform.localScale = Vector3.one * scale;
            tiles[i].sprite = frames[0];
        }
        // Frames use a bottom-left normalized pivot of (0.5, 0.125).
        cropMask.transform.localPosition = new Vector3(0f, cellHeight * 0.375f, 0f);
        cropMask.transform.localScale = new Vector3(Mathf.Max(0.001f, width), cellHeight, 1f);
        lastWidth = width;
        lastHeight = cellHeight;
        lastSpacing = spacingRatio;
        lastFirstFrame = frames[0];
    }

    private void Update()
    {
        if (frames == null || frames.Length == 0 || frames[0] == null)
        {
            foreach (SpriteRenderer tile in tiles) tile.enabled = false;
            lastFirstFrame = null;
            return;
        }
        if (!Mathf.Approximately(lastWidth, width) || !Mathf.Approximately(lastHeight, cellHeight) ||
            !Mathf.Approximately(lastSpacing, spacingRatio) || lastFirstFrame != frames[0]) Rebuild();
        elapsed += Time.deltaTime;
        int index = Mathf.FloorToInt(elapsed * Mathf.Max(1f, framesPerSecond));
        for (int i = 0; i < tiles.Count; i++)
            if (tiles[i].enabled) tiles[i].sprite = frames[(index + i * 3) % frames.Length];
    }

    private void OnDestroy()
    {
        if (maskSprite != null) Destroy(maskSprite);
        if (maskTexture != null) Destroy(maskTexture);
    }
}
