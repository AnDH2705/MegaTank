using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public sealed class SpriteFlipbook2D : MonoBehaviour
{
    public Sprite[] frames;
    [Min(1f)] public float framesPerSecond = 16f;
    public bool loop = true;
    public bool destroyOnFinish = true;
    private SpriteRenderer target;
    private float elapsed;

    private void OnEnable()
    {
        target = GetComponent<SpriteRenderer>();
        elapsed = 0f;
        if (frames != null && frames.Length > 0) target.sprite = frames[0];
    }

    private void Update()
    {
        if (frames == null || frames.Length == 0) return;
        elapsed += Time.deltaTime;
        int index = Mathf.FloorToInt(elapsed * Mathf.Max(1f, framesPerSecond));
        if (!loop && index >= frames.Length)
        {
            if (destroyOnFinish) Destroy(gameObject);
            else { target.sprite = frames[frames.Length - 1]; enabled = false; }
            return;
        }
        target.sprite = frames[loop ? index % frames.Length : index];
    }
}
