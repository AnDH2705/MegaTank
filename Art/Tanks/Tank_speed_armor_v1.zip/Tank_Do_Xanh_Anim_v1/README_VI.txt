HAI TANK ĐỎ / XANH — PART ANIM V1

01_Tank_Do_Toc_Do: bản đỏ thiên về tốc độ.
02_Tank_Xanh_Chong_Chiu: bản xanh biển chuyên chống chịu.

Mỗi mẫu có 11 part giống cách chia của tank đầu:
01 gầm/xích và hệ treo; 02–05 bốn bánh; 06 nòng pháo;
07 thân và toàn bộ nội thất tĩnh; 08 cụm súng máy;
09 nòng mortar; 10 đai kẹp/bệ mortar; 11 khung viền phía trước.

Thứ tự ghép chính xác nằm trong PSD/ORA và metadata/parts_manifest.json.
Đặt nhân vật TRÊN 07_body_static và DƯỚI 11_front_hull_frame.
Hai khoảng trong khung được để trong suốt thật. Nội thất không tách nhỏ.

parts/: PNG RGBA đã crop; JSON ghi vị trí và pivot theo pixel gốc.
Tank_Front_Frame.png và Tank_Body_Static.png: ảnh trên canvas đầy đủ.
previews/: ảnh ghép, bảng xem part và GIF kiểm tra quay bánh / recoil.
Hai mẫu có canvas riêng theo ảnh gốc; không dùng tọa độ mẫu đầu cho mẫu sau.
Bánh giữ form elip nhẹ của artwork; GIF quay theo phép chiếu elip.
Phần bị che ở nòng mortar, đỉnh bánh và nền gầm đã được phục hồi.
Đây là bộ artwork đã tách, chưa bind vào project Spine/Unity.
